export function health() { return {service:"nexus-api", status:"ok", timestamp:new Date().toISOString()}; }
