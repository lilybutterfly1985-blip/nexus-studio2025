// tax domain module
export type RecordMap = Record<string, unknown>;

export function calculateTax(input: RecordMap = {}) { return 0; }
