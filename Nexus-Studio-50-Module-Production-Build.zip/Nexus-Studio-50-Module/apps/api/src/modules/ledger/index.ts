// ledger domain module
export type RecordMap = Record<string, unknown>;

export function recordLedgerEntry(input: RecordMap = {}) { return { id: crypto.randomUUID(), status: 'OK' }; }
export function getLedgerBalance(input: RecordMap = {}) { return []; }
