export type OrderStatus = "PENDING"|"PAID"|"CANCELLED"|"REFUNDED";
export interface Order { id:string; userId:string; productId:string; amount:number; status:OrderStatus; createdAt:Date; }
export function createOrder(input:{userId:string;productId:string;amount:number}):Order {
  if (!input.userId || !input.productId) throw new Error("userId and productId are required");
  if (!Number.isFinite(input.amount) || input.amount < 0) throw new Error("Invalid amount");
  return {id:crypto.randomUUID(),...input,status:"PAID",createdAt:new Date()};
}
export function canCancel(order:Order){return order.status==="PENDING"||order.status==="PAID";}
export function cancelOrder(order:Order):Order {
  if(!canCancel(order)) throw new Error("Order cannot be cancelled");
  return {...order,status:"CANCELLED"};
}
