export interface JournalLine { accountId:string; debit:number; credit:number; }
export function validateJournal(lines:JournalLine[]) {
  if (!lines.length) throw new Error("Journal requires lines");
  const debit=lines.reduce((s,l)=>s+l.debit,0);
  const credit=lines.reduce((s,l)=>s+l.credit,0);
  if (Math.abs(debit-credit)>0.000001) throw new Error("Journal is not balanced");
  return true;
}
export function createJournalEntry(input:{description:string;lines:JournalLine[]}) {
  validateJournal(input.lines);
  return {id:crypto.randomUUID(),...input,status:"POSTED",createdAt:new Date()};
}
