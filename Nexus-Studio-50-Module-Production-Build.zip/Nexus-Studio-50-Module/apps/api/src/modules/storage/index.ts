// storage domain module
export type RecordMap = Record<string, unknown>;

export function createObjectKey(input: RecordMap = {}) { return { id: crypto.randomUUID(), status: 'OK' }; }
export function signObjectUrl(input: RecordMap = {}) { return { id: crypto.randomUUID(), token: crypto.randomUUID(), status: 'ACTIVE' }; }
