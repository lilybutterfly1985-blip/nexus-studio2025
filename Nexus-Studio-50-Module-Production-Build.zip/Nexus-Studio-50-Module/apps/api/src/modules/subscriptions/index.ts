// subscriptions domain module
export type RecordMap = Record<string, unknown>;

export function createSubscription(input: RecordMap = {}) { return { id: crypto.randomUUID(), status: 'OK' }; }
export function cancelSubscription(input: RecordMap = {}) { return true; }
