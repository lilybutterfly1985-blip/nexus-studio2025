// coupons domain module
export type RecordMap = Record<string, unknown>;

export function createCoupon(input: RecordMap = {}) { return { id: crypto.randomUUID(), status: 'OK' }; }
export function validateCoupon(input: RecordMap = {}) { return true; }
export function applyCoupon(input: RecordMap = {}) { return { id: crypto.randomUUID(), status: 'OK' }; }
