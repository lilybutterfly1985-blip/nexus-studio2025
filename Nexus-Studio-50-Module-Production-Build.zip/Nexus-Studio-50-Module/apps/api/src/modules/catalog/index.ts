// catalog domain module
export type RecordMap = Record<string, unknown>;

export function listProducts(input: RecordMap = {}) { return []; }
export function getFeaturedProducts(input: RecordMap = {}) { return []; }
export function getCategories(input: RecordMap = {}) { return []; }
