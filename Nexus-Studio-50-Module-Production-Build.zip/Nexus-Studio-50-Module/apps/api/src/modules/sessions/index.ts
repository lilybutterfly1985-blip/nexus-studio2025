// sessions domain module
export type RecordMap = Record<string, unknown>;

export function createSession(input: RecordMap = {}) { return { id: crypto.randomUUID(), status: 'OK' }; }
export function revokeSession(input: RecordMap = {}) { return { success: true }; }
