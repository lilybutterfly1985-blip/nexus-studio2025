// users domain module
export type RecordMap = Record<string, unknown>;

export function createUser(input: RecordMap = {}) { return { id: crypto.randomUUID(), status: 'OK' }; }
export function getUser(input: RecordMap = {}) { return []; }
export function updateUser(input: RecordMap = {}) { return { id: crypto.randomUUID(), status: 'OK' }; }
export function deleteUser(input: RecordMap = {}) { return { success: true }; }
