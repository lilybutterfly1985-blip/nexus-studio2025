// notifications domain module
export type RecordMap = Record<string, unknown>;

export function createNotification(input: RecordMap = {}) { return { id: crypto.randomUUID(), status: 'OK' }; }
export function listNotifications(input: RecordMap = {}) { return []; }
export function markRead(input: RecordMap = {}) { return { id: crypto.randomUUID(), status: 'OK' }; }
