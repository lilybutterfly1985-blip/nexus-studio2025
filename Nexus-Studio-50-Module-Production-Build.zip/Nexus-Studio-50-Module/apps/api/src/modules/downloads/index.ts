export function canDownload(purchased:boolean){return purchased;}
export function createSecureDownload(input:{purchased:boolean;fileUrl:string}){
  if(!input.purchased) throw new Error("Purchase required");
  if(!input.fileUrl) throw new Error("File unavailable");
  return {url:input.fileUrl,expiresAt:new Date(Date.now()+15*60_000)};
}
