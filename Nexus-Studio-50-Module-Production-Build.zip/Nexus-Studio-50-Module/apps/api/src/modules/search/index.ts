// search domain module
export type RecordMap = Record<string, unknown>;

export function searchProducts(input: RecordMap = {}) { return { id: crypto.randomUUID(), status: 'OK' }; }
export function filterProducts(input: RecordMap = {}) { return { id: crypto.randomUUID(), status: 'OK' }; }
