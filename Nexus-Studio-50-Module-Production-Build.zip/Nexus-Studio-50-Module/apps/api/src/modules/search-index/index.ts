// search-index domain module
export type RecordMap = Record<string, unknown>;

export function indexProduct(input: RecordMap = {}) { return { id: crypto.randomUUID(), status: 'OK' }; }
export function removeProduct(input: RecordMap = {}) { return { success: true }; }
