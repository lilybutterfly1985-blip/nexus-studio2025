// imports domain module
export type RecordMap = Record<string, unknown>;

export function validateImport(input: RecordMap = {}) { return true; }
export function importRows(input: RecordMap = {}) { return { id: crypto.randomUUID(), status: 'OK' }; }
