// refunds domain module
export type RecordMap = Record<string, unknown>;

export function requestRefund(input: RecordMap = {}) { return { id: crypto.randomUUID(), status: 'OK' }; }
export function approveRefund(input: RecordMap = {}) { return { id: crypto.randomUUID(), status: 'OK' }; }
