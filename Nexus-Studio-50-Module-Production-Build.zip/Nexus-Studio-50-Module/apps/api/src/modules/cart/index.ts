// cart domain module
export type RecordMap = Record<string, unknown>;

export function addItem(input: RecordMap = {}) { return { id: crypto.randomUUID(), status: 'OK' }; }
export function removeItem(input: RecordMap = {}) { return { success: true }; }
export function getCart(input: RecordMap = {}) { return []; }
export function clearCart(input: RecordMap = {}) { return { success: true }; }
