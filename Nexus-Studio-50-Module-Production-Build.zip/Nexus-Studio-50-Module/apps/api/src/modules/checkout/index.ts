// checkout domain module
export type RecordMap = Record<string, unknown>;

export function validateCheckout(input: RecordMap = {}) { return true; }
export function calculateTotal(input: RecordMap = {}) { return 0; }
