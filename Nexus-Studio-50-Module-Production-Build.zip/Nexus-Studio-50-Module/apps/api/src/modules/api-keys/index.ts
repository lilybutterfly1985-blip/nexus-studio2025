// api-keys domain module
export type RecordMap = Record<string, unknown>;

export function createApiKey(input: RecordMap = {}) { return { id: crypto.randomUUID(), token: crypto.randomUUID(), status: 'ACTIVE' }; }
export function revokeApiKey(input: RecordMap = {}) { return { success: true }; }
