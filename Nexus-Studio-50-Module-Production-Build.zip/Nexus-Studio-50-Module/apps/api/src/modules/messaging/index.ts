// messaging domain module
export type RecordMap = Record<string, unknown>;

export function sendMessage(input: RecordMap = {}) { return { id: crypto.randomUUID(), status: 'OK' }; }
export function listMessages(input: RecordMap = {}) { return []; }
