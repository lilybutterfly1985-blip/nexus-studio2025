// security domain module
export type RecordMap = Record<string, unknown>;

export function hashToken(input: RecordMap = {}) { return { id: crypto.randomUUID(), token: crypto.randomUUID(), status: 'ACTIVE' }; }
export function constantTimeEqual(input: RecordMap = {}) { return { id: crypto.randomUUID(), token: crypto.randomUUID(), status: 'ACTIVE' }; }
