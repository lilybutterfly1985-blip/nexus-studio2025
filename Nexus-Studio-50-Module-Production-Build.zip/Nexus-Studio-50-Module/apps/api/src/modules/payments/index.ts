// payments domain module
export type RecordMap = Record<string, unknown>;

export function createPayment(input: RecordMap = {}) { return { id: crypto.randomUUID(), status: 'OK' }; }
export function confirmPayment(input: RecordMap = {}) { return { id: crypto.randomUUID(), status: 'OK' }; }
export function refundPayment(input: RecordMap = {}) { return { id: crypto.randomUUID(), status: 'OK' }; }
