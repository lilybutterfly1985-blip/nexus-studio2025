// categories domain module
export type RecordMap = Record<string, unknown>;

export function createCategory(input: RecordMap = {}) { return { id: crypto.randomUUID(), status: 'OK' }; }
export function renameCategory(input: RecordMap = {}) { return { id: crypto.randomUUID(), status: 'OK' }; }
export function deleteCategory(input: RecordMap = {}) { return { success: true }; }
