// shipping domain module
export type RecordMap = Record<string, unknown>;

export function calculateShipping(input: RecordMap = {}) { return 0; }
