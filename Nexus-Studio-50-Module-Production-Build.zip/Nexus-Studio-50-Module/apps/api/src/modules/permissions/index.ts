// permissions domain module
export type RecordMap = Record<string, unknown>;

export function canAccess(input: RecordMap = {}) { return true; }
