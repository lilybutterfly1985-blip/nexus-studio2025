// moderation domain module
export type RecordMap = Record<string, unknown>;

export function flagContent(input: RecordMap = {}) { return { id: crypto.randomUUID(), status: 'OK' }; }
export function resolveFlag(input: RecordMap = {}) { return { id: crypto.randomUUID(), status: 'OK' }; }
