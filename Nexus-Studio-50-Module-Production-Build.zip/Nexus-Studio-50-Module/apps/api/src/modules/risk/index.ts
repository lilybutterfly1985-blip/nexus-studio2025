// risk domain module
export type RecordMap = Record<string, unknown>;

export function riskLevel(input: RecordMap = {}) { return 0; }
