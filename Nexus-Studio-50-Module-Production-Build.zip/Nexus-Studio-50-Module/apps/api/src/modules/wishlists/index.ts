// wishlists domain module
export type RecordMap = Record<string, unknown>;

export function addWishlist(input: RecordMap = {}) { return { id: crypto.randomUUID(), status: 'OK' }; }
export function removeWishlist(input: RecordMap = {}) { return { success: true }; }
export function getWishlist(input: RecordMap = {}) { return []; }
