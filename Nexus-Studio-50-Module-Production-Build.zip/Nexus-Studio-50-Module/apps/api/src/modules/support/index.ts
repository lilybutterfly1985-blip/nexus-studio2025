// support domain module
export type RecordMap = Record<string, unknown>;

export function createTicket(input: RecordMap = {}) { return { id: crypto.randomUUID(), status: 'OK' }; }
export function listTickets(input: RecordMap = {}) { return []; }
export function closeTicket(input: RecordMap = {}) { return { success: true }; }
