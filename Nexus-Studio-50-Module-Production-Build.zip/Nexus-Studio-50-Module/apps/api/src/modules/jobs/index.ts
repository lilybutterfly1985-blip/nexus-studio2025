// jobs domain module
export type RecordMap = Record<string, unknown>;

export function enqueueJob(input: RecordMap = {}) { return { id: crypto.randomUUID(), status: 'OK' }; }
export function runJob(input: RecordMap = {}) { return { id: crypto.randomUUID(), status: 'OK' }; }
