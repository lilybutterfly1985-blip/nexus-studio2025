// payouts domain module
export type RecordMap = Record<string, unknown>;

export function calculateCreatorPayout(input: RecordMap = {}) { return 0; }
export function createPayout(input: RecordMap = {}) { return { id: crypto.randomUUID(), status: 'OK' }; }
