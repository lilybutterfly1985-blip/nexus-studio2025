// webhooks domain module
export type RecordMap = Record<string, unknown>;

export function verifyWebhook(input: RecordMap = {}) { return true; }
export function handleWebhook(input: RecordMap = {}) { return { id: crypto.randomUUID(), status: 'OK' }; }
