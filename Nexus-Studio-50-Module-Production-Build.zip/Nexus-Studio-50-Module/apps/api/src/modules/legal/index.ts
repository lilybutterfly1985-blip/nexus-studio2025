// legal domain module
export type RecordMap = Record<string, unknown>;

export function acceptTerms(input: RecordMap = {}) { return { id: crypto.randomUUID(), status: 'OK' }; }
export function getConsent(input: RecordMap = {}) { return []; }
