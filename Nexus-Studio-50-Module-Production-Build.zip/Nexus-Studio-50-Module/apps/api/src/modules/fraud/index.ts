// fraud domain module
export type RecordMap = Record<string, unknown>;

export function scoreTransaction(input: RecordMap = {}) { return 0; }
export function shouldReview(input: RecordMap = {}) { return true; }
