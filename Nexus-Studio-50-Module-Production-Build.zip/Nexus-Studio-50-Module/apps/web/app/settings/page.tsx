export default function Page(){return <main><h1>Settings</h1><p>Nexus Studio Settings module.</p></main>}
