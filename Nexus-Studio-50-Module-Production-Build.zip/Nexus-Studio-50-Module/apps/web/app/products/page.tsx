export default function Page(){return <main><h1>Products</h1><p>Nexus Studio Products module.</p></main>}
