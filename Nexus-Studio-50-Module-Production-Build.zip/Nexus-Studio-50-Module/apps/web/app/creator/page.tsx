export default function Page(){return <main><h1>Creator</h1><p>Nexus Studio Creator module.</p></main>}
