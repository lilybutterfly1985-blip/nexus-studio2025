export default function Page(){return <main><h1>Reports</h1><p>Nexus Studio Reports module.</p></main>}
