export default function Page(){return <main><h1>Support</h1><p>Nexus Studio Support module.</p></main>}
