export default function Page(){return <main><h1>Dashboard</h1><p>Nexus Studio Dashboard module.</p></main>}
