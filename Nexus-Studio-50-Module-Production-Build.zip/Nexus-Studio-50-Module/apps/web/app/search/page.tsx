export default function Page(){return <main><h1>Search</h1><p>Nexus Studio Search module.</p></main>}
