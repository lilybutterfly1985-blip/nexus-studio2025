export default function Page(){return <main><h1>Notifications</h1><p>Nexus Studio Notifications module.</p></main>}
