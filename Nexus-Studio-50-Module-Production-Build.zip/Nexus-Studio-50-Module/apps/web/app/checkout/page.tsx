export default function Page(){return <main><h1>Checkout</h1><p>Nexus Studio Checkout module.</p></main>}
