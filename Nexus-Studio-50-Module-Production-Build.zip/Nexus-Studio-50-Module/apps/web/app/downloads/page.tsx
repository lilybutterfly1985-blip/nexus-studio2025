export default function Page(){return <main><h1>Downloads</h1><p>Nexus Studio Downloads module.</p></main>}
