export function Button({children, disabled=false}:{children:any;disabled?:boolean}) {
  return <button disabled={disabled}>{children}</button>;
}
export function Card({children}:{children:any}) { return <section>{children}</section>; }
