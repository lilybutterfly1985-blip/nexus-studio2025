import {createSecureDownload} from '../apps/api/src/modules/downloads';
test('requires purchase',()=>expect(()=>createSecureDownload({purchased:false,fileUrl:'x'})).toThrow());
