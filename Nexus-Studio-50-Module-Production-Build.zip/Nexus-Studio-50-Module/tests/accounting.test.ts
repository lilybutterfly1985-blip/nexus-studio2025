import {validateJournal} from '../apps/api/src/modules/accounting';
test('requires balanced journal',()=>expect(validateJournal([{accountId:'a',debit:10,credit:0},{accountId:'b',debit:0,credit:10}])).toBe(true));
