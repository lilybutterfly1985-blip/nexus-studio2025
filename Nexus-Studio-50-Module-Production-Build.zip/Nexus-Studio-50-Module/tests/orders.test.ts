import {createOrder} from '../apps/api/src/modules/orders';
test('creates paid order',()=>expect(createOrder({userId:'u',productId:'p',amount:10}).status).toBe('PAID'));
